.. index

Questões das Aulas
==================

Contents:

.. toctree::
   :maxdepth: 2
   
   exercises/exercise1/exercise.rst
   exercises/exercise2_quest1/exercise.rst
   exercises/exercise2_quest2/exercise.rst
   exercises/exercise3_quest1/exercise.rst
   exercises/exercise3_quest2/exercise.rst
   exercises/exercise3_quest3/exercise.rst
   exercises/exercise4_quest2/exercise.rst

